# Women in STEM — SwiftUI Workshop App

An iOS app used to teach an introduction to SwiftUI workshop for women. The app showcases women in STEM while participants learn SwiftUI fundamentals by building real UI components, views and navigation flows. 

**Link to figma**: https://www.figma.com/design/QsLEtqHHBDhXABfHJfxMUQ/Oficina-de-Desenvolvimento-iOS?node-id=0-1&t=uOzd7I8gum41teHv-1

| <img width="300" height="1704" alt="image" src="https://github.com/user-attachments/assets/38a6c0af-2ff1-4b4b-b184-e18bd07df9be" /> | <img width="300" height="1704" alt="image" src="https://github.com/user-attachments/assets/fca52f5c-3e70-4ddb-b4d0-6338bb570cf3" /> | <img width="300" height="1704" alt="image" src="https://github.com/user-attachments/assets/f45c38a1-b256-4f0a-9d94-c6811aaff509" />

