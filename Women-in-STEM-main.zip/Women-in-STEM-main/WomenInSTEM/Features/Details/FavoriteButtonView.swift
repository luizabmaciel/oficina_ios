//
//  FavoriteButtonView.swift
//  WomenInSTEM
//
//  Created by Curso-12 on 29/10/25.
//

import SwiftUI

struct FavoriteButtonView: View {
    let isFavorite: Bool
    let action: () -> Void
    var body: some View {
        Button {
            action()
        } label: {
            Image(systemName: isFavorite ? "star.fill" : "star")
                .foregroundStyle(.yellow)
        }
    }
}

#Preview {
    @Previewable @State var isFavorite: Bool = false
    FavoriteButtonView(isFavorite: isFavorite, action: { isFavorite.toggle()})
}
